@java.lang.Deprecated()
module mod.one {
	exports targets.model9;

	requires java.base;
	requires java.compiler;
	requires java.sql;
}

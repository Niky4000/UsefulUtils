package question;

public enum Color { RED, WHITE, BLUE; } 
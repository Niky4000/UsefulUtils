package com.sw_engineering_candies.proxy;

public class SecretToken {

	public static final String TOKEN_KEY = "Swec-Proxy-Token";

	// TODO: Change secret token
	public static final String TOKEN_VALUE = "<Change this secret token>";

	public static final String TOKEN = TOKEN_KEY + " : " + TOKEN_VALUE;

}

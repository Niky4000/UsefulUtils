package jtcpfwd;

public class NoMoreSocketsException extends Exception {
}

This module contains an SSHD CommandFactory to support git through SSH.
The git commands are provided by a modified version of jgit-pgm
available at:
  https://github.com/gnodet/jgit/tree/413522

package com.subgraph.orchid;

public interface SocksPortListener {
	void addListeningPort(int port);
	void stop();
}

package com.subgraph.orchid;


public interface RouterMicrodescriptor extends Descriptor {

}

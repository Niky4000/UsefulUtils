package ru.ibs.testdocxtemplates;

import ru.ibs.testpumputils.ActEkmpReportFileExporter3Test;

/**
 *
 * @author me
 */
public class StartDocxTemplateTest {

    public static void main(String[] args) throws Exception {
        ActEkmpReportFileExporter3Test.test();
    }
}
